echo "source ~/quick-bashrc/bash-profile.sh" >> ~/.bashrc

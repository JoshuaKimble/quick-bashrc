# quick-bashrc

### Setup

1. `git clone https://github.com/JoshuaKimble/quick-bashrc.git ~/`

    * or with wget `wget -qO- https://github.com/JoshuaKimble/quick-bashrc/raw/master/quick-bashrc.tar.gz | tar xvz -C ~/`

2. `bash ~/quick-bashrc/install.sh && source ~/.bashrc`


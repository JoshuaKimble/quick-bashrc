# quick-bashrc

### Setup

1. git clone https://github.com/JoshuaKimble/quick-bashrc.git ~/

2. ./quick-bashrc/install.sh

